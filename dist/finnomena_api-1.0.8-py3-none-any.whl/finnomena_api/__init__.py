from finnomena_api.api import finnomenaAPI
